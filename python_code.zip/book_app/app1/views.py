import pymysql
from django.shortcuts import render, redirect, HttpResponse
from app1.models import *

def reviews(request):
    if request.method == "GET":
        return render(request, 'ReflectionAndRating.html')
    if request.method == "POST":
        reflection = request.POST.get("reflection", None)
        stars = request.POST.get("stars", None)
        id = request.POST.get("id", None)
        print(reflection, stars)

        db = pymysql.connect(host="localhost", port=3306, user="root", passwd="root", db="testdb", charset='utf8')
        cursor = db.cursor()
        sql1 = """
        insert into ReflectionAndRating values ('1','"""+reflection+"""',"""+stars+""");
         """
        sql2 = """
         update books set b_rating=(select avg(rating) from ReflectionAndRating where b_no='"""+id+"""') where 1=1;
        """
        cursor.execute(sql2)
        db.commit()
        try:
            cursor.execute(sql1)
            db.commit()
        except:
            db.rollback()

        try:
            cursor.execute(sql2)
            db.commit()
        except:
            db.rollback()

        sql3 = """
          select b_rating from books  where b_no="""+id+""";
         """
        cursor.execute(sql3)
        avg_rating = cursor.fetchone()[0]
        print(avg_rating)
        # print(avg_rating.b_rating)
        # print(avg_rating.b_rating)
        #  {{ mod_obj.b_rating }}
        db.close()
        return render(request, 'result.html', {'avg_rating': avg_rating})